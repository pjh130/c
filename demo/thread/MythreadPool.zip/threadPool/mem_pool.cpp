#include "stdafx.h"
#include "mem_pool.h"
//#include "../auto_lock.h"

//--------------------------------------------MemBlock----------------------------------------------------
#define LOG_TAG "mem pool"

FixedMemBlock::FixedMemBlock(UINT unitSize, USHORT unitCount) :
m_blockTotalSize(unitSize * unitCount),
m_freeUnitCount(unitCount - 1),
m_firstFreeIndex(1),
m_pNextBlock(NULL),
m_unitSize(unitSize)
{
	char *p = m_firstByte;
	//the min index is 1, max index is (unitCount - 1)
	//0th unit points to 1th unit, 1th points to 2th...(unitCount-2)th points to (unitCount-1)

	for (int i = 1; i <= unitCount - 1; ++i)
	{
		(*(USHORT *)p) = i;
		p += unitSize;
	}
}

FixedMemBlock::~FixedMemBlock()
{}

void *FixedMemBlock::getFirstFreeUnit()
{
	void *pRet = NULL;
	if(m_freeUnitCount > 0)
	{
		pRet = m_firstByte + ((UINT)m_firstFreeIndex) * m_unitSize;
#ifdef FIXEDMEMPOOL_DEBUG
		PRINT_I(LOG_TAG, "alloc unit %i %i  from %i", m_firstFreeIndex, pRet, this);
#endif
		m_firstFreeIndex = *(USHORT *)pRet;
		m_freeUnitCount--;
#ifdef FIXEDMEMPOOL_DEBUG
		PRINT_I(LOG_TAG, "next unit %i", m_firstFreeIndex);
		PRINT_I(LOG_TAG, "current unit count %i", m_freeUnitCount);
		PRINT_I(LOG_TAG, "--------------------------");
#endif
	}
	return pRet;
}

bool FixedMemBlock::containsUnit(void *addr)
{
	ULONG l = (ULONG)addr;
	return (l >= (ULONG)(m_firstByte) && l < (ULONG)(m_firstByte + m_blockTotalSize));
}

void FixedMemBlock::releaseUnit(void *p)
{
	//when invoke this method, should guarantee that p definitely belongs to this block
	//so it's private, not allow user to invoke it
	//write the pre-free index to the head of the unit
	*(USHORT *)p = m_firstFreeIndex;
	m_firstFreeIndex = (USHORT)(((ULONG)p - (ULONG)(m_firstByte)) / m_unitSize);
	m_freeUnitCount++;
#ifdef FIXEDMEMPOOL_DEBUG
	PRINT_I(LOG_TAG, "release unit %i  from %i", m_firstFreeIndex, this);
	PRINT_I(LOG_TAG, "current unit count %i", m_freeUnitCount);
#endif
}

void * FixedMemBlock::operator new(size_t, UINT unitSize, UINT unitCount)
{
	void *ret = ::operator new(sizeof(FixedMemBlock) + unitSize * unitCount);
#ifdef FIXEDMEMPOOL_DEBUG
	PRINT_I(LOG_TAG, "alloc new block %i", ret);
#endif
	return ret;
}

void FixedMemBlock::operator delete(void *p, UINT unitSize, UINT unitCount)
{
	if (p)::operator delete(p);
}

void FixedMemBlock::operator delete(void *p, size_t)
{
#ifdef FIXEDMEMPOOL_DEBUG
	PRINT_I(LOG_TAG, "release block %i", p);
#endif
	if (p)::operator delete(p);
}



//--------------------------------------------MemPool----------------------------------------------------

FixedMemPool::FixedMemPool():
m_pBlockHead(NULL),
m_blockCount(0),
m_autoReleaseFreeBlock(false),
m_maxReserveBlocksCount(0),
m_totalAllocSize(0),
m_isInited(false),
m_unitSize(0),
m_unitCountPerBlock(0)
{
}

FixedMemPool::FixedMemPool(UINT unitSize, USHORT unitCountPerBlock) :
m_pBlockHead(NULL),
m_blockCount(0),
m_autoReleaseFreeBlock(false),
m_maxReserveBlocksCount(0),
m_totalAllocSize(0),
m_isInited(false),
m_unitSize(0),
m_unitCountPerBlock(0)
{
	prepare(unitSize, unitCountPerBlock);
}

FixedMemPool::~FixedMemPool()
{
	merge();
//	HDS_MUTEX_DESTROY(&m_lock);
}

int FixedMemPool::prepare(UINT unitSize, USHORT unitCountPerBlock)
{
	int ret = -1;
	do
	{
		if(m_isInited)
			break;

		if(unitSize <= 0)
			break;

		if(unitCountPerBlock <= 0)
			break;

		m_unitSize = unitSize;
		m_unitCountPerBlock = unitCountPerBlock;
//		HDS_MUTEX_INIT(&m_lock);

		m_unitSize += 20;
		if(m_unitSize > MEMPOOL_MIN_UNIT_SIZE)
			m_unitSize = (m_unitSize + (MEMPOOL_ALIGNMENT - 1)) & ~(MEMPOOL_ALIGNMENT - 1);
		else
			m_unitSize = MEMPOOL_MIN_UNIT_SIZE;

		m_isInited = true;
		ret = 1;
	}while(0);
	return ret;
}

void * FixedMemPool::alloc()
{
	void *pRet = NULL;
	do
	{
		if(!m_isInited)
			break;

//		AutoLock lock(m_lock);
		FixedMemBlock *pBlock = m_pBlockHead;

		//try to find a block that has free unit
		while(pBlock && ( 0 == pBlock->m_freeUnitCount ))
			pBlock = pBlock->m_pNextBlock;

		if(NULL == pBlock)
			pRet = allocNewBlock();
		else
			pRet = pBlock->getFirstFreeUnit();

	}while(0);
	return pRet;
}

void *FixedMemPool::allocNewBlock()
{
	FixedMemBlock *pBlock = new(m_unitSize, m_unitCountPerBlock)FixedMemBlock(m_unitSize, m_unitCountPerBlock);

	if (!pBlock)
		return NULL;

	m_totalAllocSize += pBlock->m_blockTotalSize;
	m_blockCount++;
#ifdef FIXEDMEMPOOL_DEBUG
	PRINT_I(LOG_TAG, "current block count %i", m_blockCount);
#endif

	//insert into block linked-list head and then return the 0th unit
	pBlock->m_pNextBlock = m_pBlockHead;
	m_pBlockHead = pBlock;
#ifdef FIXEDMEMPOOL_DEBUG
	PRINT_I(LOG_TAG, "--------------------------");
#endif
	return (void *)pBlock->m_firstByte;
}

int FixedMemPool::release( void *p )
{
	int ret = -1;
	do
	{
		if(!m_isInited)
			break;

//		AutoLock lock(m_lock);
		FixedMemBlock *pPreBlock = NULL;
		FixedMemBlock *pBlock = m_pBlockHead;

		while(pBlock && !pBlock->containsUnit(p))
		{
			pPreBlock = pBlock;
			pBlock = pBlock->m_pNextBlock;
		}

		if (!pBlock)
			break;

		pBlock->releaseUnit(p);

		//when block becomes totally unused, it may be deleted conditionally
		if (m_autoReleaseFreeBlock && pBlock->m_freeUnitCount == m_unitCountPerBlock)
		{
			if (m_blockCount > m_maxReserveBlocksCount)
			{
				if(pBlock == m_pBlockHead)
					m_pBlockHead = pBlock->m_pNextBlock;
				else
					pPreBlock->m_pNextBlock = pBlock->m_pNextBlock;

				m_blockCount--;
				delete(pBlock);
			}
		}
		else
		{
			//move the block that just reserved unit to the head of linked-list
			if(pBlock != m_pBlockHead)
			{
				pPreBlock->m_pNextBlock = pBlock->m_pNextBlock;
				pBlock->m_pNextBlock = m_pBlockHead;
				m_pBlockHead = pBlock;
			}
		}
		ret = 1;

#ifdef FIXEDMEMPOOL_DEBUG
		PRINT_I(LOG_TAG, "current head block  %i", m_pBlockHead);
		PRINT_I(LOG_TAG, "--------------------------");
#endif
	}while(0);
	return ret;
}

void FixedMemPool::merge()
{
	if(m_isInited)
	{
		FixedMemBlock *pBlock = m_pBlockHead;
		while(pBlock)
		{
			m_pBlockHead = m_pBlockHead->m_pNextBlock;
			delete(pBlock);
			pBlock = m_pBlockHead;
		}

		m_pBlockHead = NULL;
		m_blockCount = 0;
		m_totalAllocSize = 0;
	}
}

void FixedMemPool::reset()
{
	merge();
	m_pBlockHead = NULL;
	m_blockCount = 0;
	m_autoReleaseFreeBlock = false;
	m_maxReserveBlocksCount = 0;
	m_totalAllocSize = 0;
	m_unitSize = 0;
	m_unitCountPerBlock = 0;
	m_isInited = false;
}

UINT FixedMemPool::getUsedAllocSize()
{
//	AutoLock lock(m_lock);
	return (m_totalAllocSize - getFreeAllocSize());
}

UINT FixedMemPool::getFreeAllocSize()
{
	UINT size = 0;
	FixedMemBlock *pBlock = m_pBlockHead;
	while(pBlock)
	{
		size += pBlock->m_freeUnitCount * m_unitSize;
		pBlock = pBlock->m_pNextBlock;
	}
	return size;
}
