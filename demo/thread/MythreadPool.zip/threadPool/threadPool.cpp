// threadPool.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include "thread.h"
#include "ThreadPoolExecutor.h"
#include <iostream>
using namespace std;

const int COUNT=100;

class R : public Runnable
{
public:
	R(int n):m_int(n)
	{
	
	}
	~R()
	{
		printf("~R\n");
	}
	void Run()
	{
		static int i=0;
		printf("Hello World,m_int:%d,%d\n",m_int,i++);
	}
private:
	int m_int;
};

int _tmain(int argc, _TCHAR* argv[])
{
	CThreadPoolExecutor * pExecutor = new CThreadPoolExecutor();
	pExecutor->Init(4, 10, 50);
	R * r[COUNT];
	for(int i=0;i<COUNT;i++)
		r[i]=new R(i);
	for(int i=0;i<COUNT;i++)
	{
		
		while(!pExecutor->Execute(r[i]))
		{
		}
	}
	pExecutor->Terminate();
	delete pExecutor;
	getchar();
	
	
	return 0;
}

