#ifndef _FIXEDMEMPOOL_H_
#define _FIXEDMEMPOOL_H_

//#define FIXEDMEMPOOL_DEBUG
#ifdef FIXEDMEMPOOL_DEBUG
#include "../log.h"
#endif

#include <cstddef>
//#include "../hds_mutex.h"


/*
 * author:lrf
 * easy memory pool that is thread-safe and mem-align
 */

typedef unsigned int UINT;
typedef unsigned long ULONG;
typedef unsigned short USHORT;

const USHORT DEFAULT_UNIT_SIZE = 32;
const USHORT MEMPOOL_ALIGNMENT = 8;
const USHORT MEMPOOL_MAX_RESERVE_BLOCK_COUNT = 1;
const USHORT MEMPOOL_MIN_UNIT_SIZE = 4;

class FixedMemPool;

class FixedMemBlock
{
	friend class FixedMemPool;
public:
	FixedMemBlock(UINT unitSize, USHORT unitCount);
	~FixedMemBlock();

	static inline void * operator new(size_t, UINT unitSize, UINT unitCount);
	static inline void operator delete(void *p, UINT unitSize, UINT unitCount);
	static inline void operator delete(void *p, size_t);

private:
	void *getFirstFreeUnit();//pop one free unit if this block has
	bool containsUnit(void *addr);//check whether addr belongs to this block
	void releaseUnit(void *p);//need to guarantee that p must belong to this block

private:
	UINT m_blockTotalSize;
	USHORT m_freeUnitCount;
	USHORT m_firstFreeIndex;
	UINT m_unitSize;
	FixedMemBlock *m_pNextBlock;
	char m_firstByte[1];
};

class FixedMemPool
{
public:
	FixedMemPool();
	FixedMemPool(UINT unitSize, USHORT unitCountPerBlock);
	~FixedMemPool();

	int prepare(UINT unitSize, USHORT unitCountPerBlock);
	void * alloc();
	int release(void *p);
	void merge();
	void reset();
	UINT getUsedAllocSize();

	inline void setAutoReleaseBlock(bool b){m_autoReleaseFreeBlock = b;}
	inline bool isAutoReleaseBlock(){return m_autoReleaseFreeBlock;}
	inline void setMaxReserveBlocksCount(USHORT count){m_maxReserveBlocksCount = count;}
	inline USHORT getMaxReserveBlocksCount(){return m_maxReserveBlocksCount;}
	inline int getTotalAllocSize(){return m_totalAllocSize;}
	inline UINT getUnitSize(){return m_unitSize;}

private:
	FixedMemPool(const FixedMemPool &);
	FixedMemPool & operator=(const FixedMemPool &);

	void *allocNewBlock();
	UINT getFreeAllocSize();

private:
	UINT m_unitSize;
	USHORT m_unitCountPerBlock;
	USHORT m_blockCount;
	FixedMemBlock *m_pBlockHead;
	bool m_autoReleaseFreeBlock;
	USHORT m_maxReserveBlocksCount;
	UINT m_totalAllocSize;
	bool m_isInited;
//	HDSMutex m_lock;
};

#endif
